public interface Acao {
    void executa();
}